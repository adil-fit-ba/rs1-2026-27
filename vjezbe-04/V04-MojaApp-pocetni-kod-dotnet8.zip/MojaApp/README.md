# MojaApp – RS1 vježbe 4, početni kod

Početni kod za V04 je rješenje V03 (bez izmjena). Baza iz V03 radi; ko nema bazu, pokreće `Update-Database`.

## Rješenje V03

ASP.NET Core Web API (.NET 8), EF Core, SQL Server. Entiteti: `Student`, `Smjer` (1:N), `Predmet` i `Upis` (M:N s podacima: datum upisa i ocjena).

Migracije: `Pocetna` (V02), `Smjerovi`, `PredmetiIUpisi`. Baza: `Update-Database` (ili `dotnet ef database update`).

Kontroleri: `Studenti` (projekcija sa smjerom, detalji s upisima, brisanje s provjerom upisa), `Smjerovi`, `Predmeti` (zadaci 1, 3, 4), `Upisi` (upis, ocjena – zadatak 2, ispis – zadatak 5).

SQL upiti se u Developmentu ispisuju u konzolu (`appsettings.Development.json`). Zahtjevi za testiranje su u `MojaApp.API/MojaApp.API.http`.
