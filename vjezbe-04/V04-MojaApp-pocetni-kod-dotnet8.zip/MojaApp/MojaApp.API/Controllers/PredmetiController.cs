using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MojaApp.API.Data;
using MojaApp.API.Dtos;
using MojaApp.API.Models;

namespace MojaApp.API.Controllers;

[ApiController]
[Route("[controller]")]
public class PredmetiController(AppDbContext db) : ControllerBase
{
    // GET /Predmeti: svaki predmet s brojem upisanih studenata
    [HttpGet]
    public async Task<List<PredmetResponse>> GetAll(CancellationToken ct)
    {
        return await db.Predmeti
            .OrderBy(x => x.Naziv)
            .Select(x => new PredmetResponse
            {
                Id = x.Id,
                Naziv = x.Naziv,
                Sifra = x.Sifra,
                Ects = x.Ects,
                BrojUpisanih = x.Upisi.Count,
            })
            .ToListAsync(ct);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<PredmetResponse>> GetById(int id, CancellationToken ct)
    {
        PredmetResponse? predmet = await db.Predmeti
            .Where(x => x.Id == id)
            .Select(x => new PredmetResponse
            {
                Id = x.Id,
                Naziv = x.Naziv,
                Sifra = x.Sifra,
                Ects = x.Ects,
                BrojUpisanih = x.Upisi.Count,
            })
            .FirstOrDefaultAsync(ct);

        if (predmet == null)
            return NotFound();

        return predmet;
    }

    // Zadatak 1: POST /Predmeti, šifra predmeta je jedinstvena
    [HttpPost]
    public async Task<ActionResult<PredmetResponse>> Dodaj(PredmetDodajRequest request, CancellationToken ct)
    {
        if (await db.Predmeti.AnyAsync(x => x.Sifra == request.Sifra, ct))
            return Conflict($"Predmet sa šifrom {request.Sifra} već postoji."); // 409

        Predmet predmet = new()
        {
            Naziv = request.Naziv,
            Sifra = request.Sifra,
            Ects = request.Ects,
        };

        db.Predmeti.Add(predmet);
        await db.SaveChangesAsync(ct);

        return CreatedAtAction(nameof(GetById), new { id = predmet.Id }, new PredmetResponse
        {
            Id = predmet.Id,
            Naziv = predmet.Naziv,
            Sifra = predmet.Sifra,
            Ects = predmet.Ects,
            BrojUpisanih = 0,
        });
    }

    // Zadatak 3: GET /Predmeti/1/statistika
    [HttpGet("{id:int}/statistika")]
    public async Task<ActionResult<PredmetStatistikaResponse>> Statistika(int id, CancellationToken ct)
    {
        PredmetStatistikaResponse? statistika = await db.Predmeti
            .Where(x => x.Id == id)
            .Select(x => new PredmetStatistikaResponse
            {
                PredmetId = x.Id,
                Naziv = x.Naziv,
                BrojUpisanih = x.Upisi.Count,
                BrojPolozenih = x.Upisi.Count(u => u.Ocjena != null),
                // Average nad praznim skupom: cast na double? daje null umjesto greške
                ProsjecnaOcjena = x.Upisi.Where(u => u.Ocjena != null).Average(u => (double?)u.Ocjena),
            })
            .FirstOrDefaultAsync(ct);

        if (statistika == null)
            return NotFound();

        return statistika;
    }

    // Zadatak 4: DELETE /Predmeti/{id}, predmet s upisima se ne briše
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Obrisi(int id, CancellationToken ct)
    {
        Predmet? predmet = await db.Predmeti.FirstOrDefaultAsync(x => x.Id == id, ct);

        if (predmet == null)
            return NotFound();

        if (await db.Upisi.AnyAsync(x => x.PredmetId == id, ct))
            return Conflict("Predmet ima upisane studente i ne može se obrisati."); // 409

        db.Predmeti.Remove(predmet);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }
}
