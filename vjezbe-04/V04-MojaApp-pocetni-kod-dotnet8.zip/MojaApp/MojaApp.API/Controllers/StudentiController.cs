using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MojaApp.API.Data;
using MojaApp.API.Dtos;
using MojaApp.API.Models;

namespace MojaApp.API.Controllers;

[ApiController]
[Route("[controller]")]
public class StudentiController(AppDbContext db) : ControllerBase
{
    // GET /Studenti?pretraga=ana
    [HttpGet]
    public async Task<List<StudentResponse>> GetAll([FromQuery] string? pretraga, CancellationToken ct)
    {
        IQueryable<Student> upit = db.Studenti;

        if (!string.IsNullOrWhiteSpace(pretraga))
            upit = upit.Where(x => x.Ime.Contains(pretraga)
                                || x.Prezime.Contains(pretraga)
                                || x.BrojIndeksa.Contains(pretraga));

        return await upit
            .OrderBy(x => x.Prezime).ThenBy(x => x.Ime)
            // Projekcija: EF Core pravi jedan SELECT samo s potrebnim kolonama i JOIN-om na Smjerovi
            .Select(x => new StudentResponse
            {
                Id = x.Id,
                ImePrezime = x.Ime + " " + x.Prezime,
                BrojIndeksa = x.BrojIndeksa,
                DatumRodjenja = x.DatumRodjenja,
                Smjer = x.Smjer != null ? x.Smjer.Naziv : null, // LEFT JOIN Smjerovi
            })
            .ToListAsync(ct);
    }

    // GET /Studenti/5: student s upisanim predmetima i ocjenama
    [HttpGet("{id:int}")]
    public async Task<ActionResult<StudentDetaljiResponse>> GetById(int id, CancellationToken ct)
    {
        StudentDetaljiResponse? student = await db.Studenti
            .Where(x => x.Id == id)
            .Select(x => new StudentDetaljiResponse
            {
                Id = x.Id,
                ImePrezime = x.Ime + " " + x.Prezime,
                BrojIndeksa = x.BrojIndeksa,
                Smjer = x.Smjer != null ? x.Smjer.Naziv : null,
                Upisi = x.Upisi
                    .OrderBy(u => u.Predmet.Naziv)
                    .Select(u => new StudentUpisResponse
                    {
                        UpisId = u.Id,
                        Predmet = u.Predmet.Naziv,
                        Sifra = u.Predmet.Sifra,
                        DatumUpisa = u.DatumUpisa,
                        Ocjena = u.Ocjena,
                    })
                    .ToList(),
            })
            .FirstOrDefaultAsync(ct);

        if (student == null)
            return NotFound();

        return student;
    }

    [HttpPost]
    public async Task<ActionResult<StudentResponse>> Dodaj(StudentDodajRequest request, CancellationToken ct)
    {
        if (await db.Studenti.AnyAsync(x => x.BrojIndeksa == request.BrojIndeksa, ct))
            return Conflict($"Student s brojem indeksa {request.BrojIndeksa} već postoji."); // 409

        if (request.SmjerId != null && !await db.Smjerovi.AnyAsync(x => x.Id == request.SmjerId, ct))
            return SmjerNePostoji();

        Student student = new()
        {
            Ime = request.Ime,
            Prezime = request.Prezime,
            BrojIndeksa = request.BrojIndeksa,
            DatumRodjenja = request.DatumRodjenja,
            DatumKreiranja = DateTime.UtcNow,
            SmjerId = request.SmjerId, // dovoljno je postaviti FK; objekat Smjer ne treba učitavati
        };

        db.Studenti.Add(student);
        await db.SaveChangesAsync(ct);

        // Odgovor s nazivom smjera: ista projekcija kao u GetAll (u V04 je izdvajamo na jedno mjesto)
        StudentResponse response = await db.Studenti
            .Where(x => x.Id == student.Id)
            .Select(x => new StudentResponse
            {
                Id = x.Id,
                ImePrezime = x.Ime + " " + x.Prezime,
                BrojIndeksa = x.BrojIndeksa,
                DatumRodjenja = x.DatumRodjenja,
                Smjer = x.Smjer != null ? x.Smjer.Naziv : null, // LEFT JOIN Smjerovi
            })
            .FirstAsync(ct);
        return CreatedAtAction(nameof(GetById), new { id = student.Id }, response);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Uredi(int id, StudentUrediRequest request, CancellationToken ct)
    {
        Student? student = await db.Studenti.FirstOrDefaultAsync(x => x.Id == id, ct);

        if (student == null)
            return NotFound();

        if (request.SmjerId != null && !await db.Smjerovi.AnyAsync(x => x.Id == request.SmjerId, ct))
            return SmjerNePostoji();

        student.Ime = request.Ime;
        student.Prezime = request.Prezime;
        student.DatumRodjenja = request.DatumRodjenja;
        student.SmjerId = request.SmjerId;

        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Obrisi(int id, CancellationToken ct)
    {
        Student? student = await db.Studenti.FirstOrDefaultAsync(x => x.Id == id, ct);

        if (student == null)
            return NotFound();

        // Upis ima OnDelete(Restrict): baza ne dozvoljava brisanje studenta koji ima upise.
        // Provjera ovdje vraća jasnu poruku (409) umjesto greške iz baze (500).
        if (await db.Upisi.AnyAsync(x => x.StudentId == id, ct))
            return Conflict("Student ima upisane predmete i ne može se obrisati.");

        db.Studenti.Remove(student);
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    // 400 u istom obliku kao greške validacije ([ApiController]): polje "SmjerId" i poruka.
    private ActionResult SmjerNePostoji()
    {
        ModelState.AddModelError(nameof(StudentDodajRequest.SmjerId), "Smjer ne postoji.");
        return ValidationProblem(ModelState);
    }
}
