using System.ComponentModel.DataAnnotations;

namespace MojaApp.API.Dtos;

// Izmjena: broj indeksa se ne mijenja, pa ga ovdje nema.
public class StudentUrediRequest
{
    [Required, StringLength(50)]
    public string Ime { get; set; } = "";

    [Required, StringLength(50)]
    public string Prezime { get; set; } = "";

    public DateOnly? DatumRodjenja { get; set; }

    public int? SmjerId { get; set; } // smjer nije obavezan
}
