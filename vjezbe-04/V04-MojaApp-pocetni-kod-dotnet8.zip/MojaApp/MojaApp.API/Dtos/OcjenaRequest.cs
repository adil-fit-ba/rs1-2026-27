using System.ComponentModel.DataAnnotations;

namespace MojaApp.API.Dtos;

public class OcjenaRequest
{
    [Range(6, 10, ErrorMessage = "Ocjena mora biti između 6 i 10.")]
    public int Ocjena { get; set; }
}
