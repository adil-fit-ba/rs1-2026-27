using System.ComponentModel.DataAnnotations;

namespace MojaApp.API.Dtos;

public class PredmetDodajRequest
{
    [Required, StringLength(100)]
    public string Naziv { get; set; } = "";

    [Required, StringLength(10)]
    public string Sifra { get; set; } = "";

    [Range(1, 30)]
    public int Ects { get; set; }
}
